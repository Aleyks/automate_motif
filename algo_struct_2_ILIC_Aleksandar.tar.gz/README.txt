Pour lancer le programme:
gcc main.c hashcode.c freel-list.c  -o automate
./automate